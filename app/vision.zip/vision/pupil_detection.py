import cv2
import numpy as np


def detect_pupil(eye_frame):
    """
    Detect pupil center and radius from cropped eye image
    """

    if eye_frame is None or eye_frame.size == 0:
        return None

    # Convert to grayscale
    gray = cv2.cvtColor(eye_frame, cv2.COLOR_BGR2GRAY)

    # Reduce noise
    gray = cv2.GaussianBlur(gray, (7, 7), 0)

    # Threshold to isolate dark pupil
    _, thresh = cv2.threshold(gray, 30, 255, cv2.THRESH_BINARY_INV)

    # Find contours
    contours, _ = cv2.findContours(
        thresh,
        cv2.RETR_TREE,
        cv2.CHAIN_APPROX_SIMPLE
    )

    if len(contours) == 0:
        return None

    # Assume largest dark region is pupil
    contour = max(contours, key=cv2.contourArea)

    (x, y), radius = cv2.minEnclosingCircle(contour)

    center = (int(x), int(y))
    radius = int(radius)

    return center, radius


def draw_pupil(eye_frame, pupil_data):
    """
    Draw pupil circle and center point
    """

    if pupil_data is None:
        return eye_frame

    center, radius = pupil_data

    cv2.circle(eye_frame, center, radius, (0, 255, 0), 2)
    cv2.circle(eye_frame, center, 2, (0, 0, 255), -1)

    return eye_frame