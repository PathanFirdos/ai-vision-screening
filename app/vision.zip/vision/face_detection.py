import cv2
import mediapipe as mp

# Initialize mediapipe face detection
mp_face_detection = mp.solutions.face_detection
mp_drawing = mp.solutions.drawing_utils

# Webcam capture
cap = cv2.VideoCapture(0)

# Approx focal length and real face width (rough estimates)
REAL_FACE_WIDTH = 16  # cm (average human face width)
FOCAL_LENGTH = 600

def estimate_distance(face_width_pixels):
    if face_width_pixels == 0:
        return None
    distance = (REAL_FACE_WIDTH * FOCAL_LENGTH) / face_width_pixels
    return round(distance, 2)

with mp_face_detection.FaceDetection(
        model_selection=0,
        min_detection_confidence=0.5) as face_detection:

    while cap.isOpened():

        ret, frame = cap.read()
        if not ret:
            break

        frame = cv2.flip(frame, 1)

        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        results = face_detection.process(rgb_frame)

        if results.detections:
            for detection in results.detections:

                bbox = detection.location_data.relative_bounding_box

                h, w, _ = frame.shape

                x = int(bbox.xmin * w)
                y = int(bbox.ymin * h)
                width = int(bbox.width * w)
                height = int(bbox.height * h)

                # Estimate distance
                distance = estimate_distance(width)

                cv2.rectangle(frame, (x, y), (x+width, y+height), (0,255,0), 2)

                if distance:
                    cv2.putText(
                        frame,
                        f"Distance: {distance} cm",
                        (x, y-10),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0,255,0),
                        2
                    )

        cv2.imshow("Vision Test Camera", frame)

        if cv2.waitKey(1) & 0xFF == 27:
            break

cap.release()
cv2.destroyAllWindows()