import cv2
import numpy as np

LEFT_EYE_IDX = [
33,7,163,144,145,153,154,155,
133,173,157,158,159,160,161,246
]

RIGHT_EYE_IDX = [
362,382,381,380,374,373,390,249,
263,466,388,387,386,385,384,398
]


def get_eye_region(frame, landmarks, indices):

    h, w, _ = frame.shape
    points = []

    for idx in indices:
        x = int(landmarks[idx].x * w)
        y = int(landmarks[idx].y * h)
        points.append([x, y])

    points = np.array(points)

    x, y, w_box, h_box = cv2.boundingRect(points)

    eye = frame[y:y+h_box, x:x+w_box]

    return eye


def extract_eyes(frame, face_landmarks):

    landmarks = face_landmarks.landmark

    left_eye = get_eye_region(frame, landmarks, LEFT_EYE_IDX)
    right_eye = get_eye_region(frame, landmarks, RIGHT_EYE_IDX)

    return left_eye, right_eye