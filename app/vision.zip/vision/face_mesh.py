import cv2
import mediapipe as mp

from app.vision.eye_extractor import extract_eyes
from app.vision.pupil_detection import detect_pupil, draw_pupil

mp_face_mesh = mp.solutions.face_mesh
mp_drawing = mp.solutions.drawing_utils

cap = cv2.VideoCapture(0)

with mp_face_mesh.FaceMesh(
        static_image_mode=False,
        max_num_faces=1,
        refine_landmarks=True,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5
) as face_mesh:

    while cap.isOpened():

        success, frame = cap.read()
        if not success:
            break

        frame = cv2.flip(frame, 1)

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        results = face_mesh.process(rgb)

        if results.multi_face_landmarks:

            for face_landmarks in results.multi_face_landmarks:

                # Draw mesh
                mp_drawing.draw_landmarks(
                    frame,
                    face_landmarks,
                    mp_face_mesh.FACEMESH_TESSELATION
                )

                # Extract eye images
                left_eye, right_eye = extract_eyes(frame, face_landmarks)

                if left_eye is not None and right_eye is not None:

                    # Detect pupils
                    left_pupil = detect_pupil(left_eye)
                    right_pupil = detect_pupil(right_eye)

                    # Draw pupils
                    left_eye = draw_pupil(left_eye, left_pupil)
                    right_eye = draw_pupil(right_eye, right_pupil)

                    cv2.imshow("Left Eye", left_eye)
                    cv2.imshow("Right Eye", right_eye)

        cv2.imshow("Face Mesh", frame)

        if cv2.waitKey(1) & 0xFF == 27:
            break

cap.release()
cv2.destroyAllWindows()